//
// Created by yidafu on 2017/11/5.
//

#ifndef CURRICULUM_DESIGN_ADMIN_H
#define CURRICULUM_DESIGN_ADMIN_H

#include "../library.h"
bool admin_entry();
bool admin_lend();
bool judge_password();
bool buy_book();
void check_lending ();
void is_borrowed();
void analyze();
#endif //CURRICULUM_DESIGN_ADMIN_H
