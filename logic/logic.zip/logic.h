//
// Created by yidafu on 2017/11/5.
//

#ifndef CURRICULUM_DESIGN_LOGIC_H
#define CURRICULUM_DESIGN_LOGIC_H

int identity();
bool judge_exit();

#endif //CURRICULUM_DESIGN_LOGIC_H
